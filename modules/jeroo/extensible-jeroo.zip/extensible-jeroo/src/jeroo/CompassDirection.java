package jeroo;

public enum CompassDirection {

    NORTH, EAST, SOUTH, WEST
}
